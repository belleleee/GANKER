'use strict';

let lastT =
    0;

function animate(
    ms
) {
    requestAnimationFrame(
        animate
    );

    const time =
        ms *
        0.001;

    const dt =
        Math.min(
            time -
            lastT,
            0.05
        );

    lastT =
        time;

    updateCoins(
        dt
    );

    updateHelper(
        time
    );

    updateGameAuto(
        time
    );

    if (
        typeof updateRoomRest ===
            'function'
    ) {
        updateRoomRest(
            time
        );
    }

    updateCamera(
        dt
    );

    renderer.render(
        scene,
        camera
    );
}

requestAnimationFrame(
    animate
);
