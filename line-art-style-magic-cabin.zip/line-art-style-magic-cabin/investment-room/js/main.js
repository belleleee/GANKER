loadState();
buildRoom();
requestAnimationFrame(animate);
