
'use strict';

const STARTING_COIN_WALLET=100;
const state={
  wallet:STARTING_COIN_WALLET,
  stake:1,
  best:1,
  roundStart:1,
  roundValue:1,
  multiplier:1,
  coinCount:1,
  coinLevel:1,
  chanceLevel:0,
  helperCount:0,
  helperStrategies:[],
  helperEmployees:[],
  selectedEmployee:0,
  activeStrategyIndex:-1,
  nextStrategyIndex:0,
  earned:0,
  lost:0,
  luckUntil:0,
  luckBought:0,
  luckStartWallet:STARTING_COIN_WALLET,
  nextTimedUi:0,
  auto:false,
  roundActive:false,
  waiting:false,
  consecutive:0,
  nextAuto:0
};

const $=id=>document.getElementById(id);
const walletEl=$('wallet'),stakeEl=$('stake'),multEl=$('multiplier'),potentialEl=$('potential');
const earnedEl=$('earned'),lostEl=$('lost'),netEl=$('net'),chanceEl=$('chance');
const hintEl=$('hint'),resultEl=$('result'),mainAction=$('mainAction');
const returnGame=$('returnGame');
const panelToggle=$('panelToggle'),sidePanel=$('sidePanel');
const strategyList=$('strategyList');
const employeeList=$('employeeList'),employeeDetail=$('employeeDetail');
const buyCoinSlot=$('buyCoinSlot'),upgradeCoin=$('upgradeCoin'),upgradeChance=$('upgradeChance'),buyHelper=$('buyHelper'),toggleAuto=$('toggleAuto');

const COIN_GAME_FALLBACK_SAVE_KEY='coinGame.v4.save';
const CABIN_SESSION_KEY='magicCabin.session.v1';
const CABIN_RETURN_KEY='magicCabin.returnFromStore.v1';
const CABIN_GUEST_ID='guest';

function readGameJson(key,fallback){
  try{
    const raw=localStorage.getItem(key);
    return raw?JSON.parse(raw):fallback;
  }catch(err){
    return fallback;
  }
}

function writeGameJson(key,value){
  try{
    localStorage.setItem(key,JSON.stringify(value));
    return true;
  }catch(err){
    return false;
  }
}

function currentCabinUserId(){
  try{
    const raw=localStorage.getItem(CABIN_SESSION_KEY);
    if(!raw)return CABIN_GUEST_ID;
    try{
      const session=JSON.parse(raw);
      if(session&&typeof session==='object'&&typeof session.id==='string'&&session.id.trim())return session.id.trim();
      if(typeof session==='string'&&session.trim())return session.trim();
    }catch(parseErr){
      if(raw.trim())return raw.trim();
    }
  }catch(err){
    return CABIN_GUEST_ID;
  }
  return CABIN_GUEST_ID;
}

function currentCabinSaveKey(){
  const id=currentCabinUserId();
  return 'magicCabin.save.'+id+'.v1';
}

function clampInt(value,fallback,min,max){
  const n=Math.trunc(Number(value));
  if(!Number.isFinite(n))return fallback;
  return Math.max(min,Math.min(max,n));
}

function defaultHelperStrategy(index){
  return {
    stake:index===0?1:2,
    cashOutAt:index===0?2.0:2.5
  };
}

function normalizeHelperStrategy(raw,index){
  const fallback=defaultHelperStrategy(index);
  const stake=clampInt(raw&&raw.stake,fallback.stake,1,100);
  const cash=Number(raw&&raw.cashOutAt);
  return {
    stake,
    cashOutAt:Number.isFinite(cash)?Math.max(1.2,Math.min(20,Math.round(cash*10)/10)):fallback.cashOutAt
  };
}

function ensureHelperStrategies(){
  while(state.helperStrategies.length<state.helperCount){
    state.helperStrategies.push(defaultHelperStrategy(state.helperStrategies.length));
  }
  state.helperStrategies=state.helperStrategies
    .slice(0,state.helperCount)
    .map((s,i)=>normalizeHelperStrategy(s,i));
}

function defaultEmployee(index){
  const colors=['#7ac7b2','#a7c985','#9bb9dc','#d3adcf'];
  const now=nowSec();
  return {
    name:'员工 '+(index+1),
    color:colors[index%colors.length],
    hiredAt:now,
    paidUntil:now+3600,
    striking:false,
    skills:{luck:0,diligent:0,cheap:0,multi:0}
  };
}

function normalizeEmployee(raw,index){
  const d=defaultEmployee(index);
  const skills=raw&&raw.skills||{};
  return {
    name:typeof raw?.name==='string'&&raw.name.trim()?raw.name.trim().slice(0,10):d.name,
    color:typeof raw?.color==='string'?raw.color:d.color,
    hiredAt:Number(raw?.hiredAt)||d.hiredAt,
    paidUntil:Number(raw?.paidUntil)||d.paidUntil,
    striking:!!raw?.striking,
    skills:{
      luck:clampInt(skills.luck,0,0,10),
      diligent:clampInt(skills.diligent,0,0,5),
      cheap:clampInt(skills.cheap,0,0,5),
      multi:clampInt(skills.multi,0,0,2)
    }
  };
}

function ensureEmployees(){
  while(state.helperEmployees.length<state.helperCount){
    state.helperEmployees.push(defaultEmployee(state.helperEmployees.length));
  }
  state.helperEmployees=state.helperEmployees
    .slice(0,state.helperCount)
    .map((e,i)=>normalizeEmployee(e,i));
  state.selectedEmployee=clampInt(state.selectedEmployee,0,0,Math.max(0,state.helperCount-1));
}

function nowSec(){
  return Date.now()/1000;
}

function applyCoinGameSave(save){
  if(!save||typeof save!=='object')return false;
  state.wallet=clampInt(save.wallet,STARTING_COIN_WALLET,0,999999);
  state.stake=clampInt(save.stake,1,1,100);
  state.best=clampInt(save.best,state.stake,1,999999);
  state.coinCount=clampInt(save.coinCount,1,1,6);
  state.coinLevel=clampInt(save.coinLevel,1,1,999);
  state.chanceLevel=clampInt(save.chanceLevel,0,0,8);
  state.helperCount=clampInt(save.helperCount,0,0,4);
  state.helperStrategies=Array.isArray(save.helperStrategies)?save.helperStrategies:[];
  state.helperEmployees=Array.isArray(save.helperEmployees)?save.helperEmployees:[];
  state.selectedEmployee=clampInt(save.selectedEmployee,0,0,3);
  ensureHelperStrategies();
  ensureEmployees();
  state.nextStrategyIndex=clampInt(save.nextStrategyIndex,0,0,3);
  state.earned=clampInt(save.earned,0,0,999999);
  state.lost=clampInt(save.lost,0,0,999999);
  state.luckUntil=Number(save.luckUntil)||0;
  state.luckBought=clampInt(save.luckBought,0,0,9999);
  state.luckStartWallet=clampInt(save.luckStartWallet,state.wallet,0,999999);
  state.auto=state.helperCount>0||!!save.auto;
  return true;
}

function captureCoinGameSave(){
  ensureHelperStrategies();
  ensureEmployees();
  return {
    wallet:Math.floor(state.wallet),
    stake:Math.floor(state.stake),
    best:Math.floor(state.best),
    coinCount:state.coinCount,
    coinLevel:state.coinLevel,
    chanceLevel:state.chanceLevel,
    helperCount:state.helperCount,
    helperStrategies:state.helperStrategies.map((s,i)=>normalizeHelperStrategy(s,i)),
    helperEmployees:state.helperEmployees.map((e,i)=>normalizeEmployee(e,i)),
    selectedEmployee:state.selectedEmployee,
    nextStrategyIndex:state.nextStrategyIndex,
    earned:state.earned,
    lost:state.lost,
    luckUntil:state.luckUntil,
    luckBought:state.luckBought,
    luckStartWallet:state.luckStartWallet,
    auto:state.auto,
    savedAt:new Date().toISOString()
  };
}

function loadCoinGameState(){
  const cabinSave=readGameJson(currentCabinSaveKey(),null);
  if(cabinSave&&typeof cabinSave==='object'){
    const economy=cabinSave.economy||{};
    const coinGame=economy.coinGame||cabinSave.coinGame||{};
    const merged=Object.assign({},coinGame);
    if(Number.isFinite(Number(economy.coins)))merged.wallet=economy.coins;
    applyCoinGameSave(merged);
    return;
  }
  const returnSave=readGameJson(CABIN_RETURN_KEY,null);
  if(returnSave&&typeof returnSave==='object'&&returnSave.economy){
    const economy=returnSave.economy||{};
    const coinGame=economy.coinGame||returnSave.coinGame||{};
    const merged=Object.assign({},coinGame);
    if(Number.isFinite(Number(economy.coins)))merged.wallet=economy.coins;
    applyCoinGameSave(merged);
    return;
  }
  applyCoinGameSave(null);
}

function saveCoinGameState(){
  const data=captureCoinGameSave();
  const cabinKey=currentCabinSaveKey();
  const cabinSave=readGameJson(cabinKey,null);
  if(cabinSave&&typeof cabinSave==='object'){
    cabinSave.economy=cabinSave.economy||{};
    cabinSave.economy.coins=data.wallet;
    cabinSave.economy.coinGame=Object.assign({},cabinSave.economy.coinGame||{},data);
    cabinSave.savedAt=data.savedAt;
    writeGameJson(cabinKey,cabinSave);
  }
  writeGameJson(COIN_GAME_FALLBACK_SAVE_KEY,data);
}

function coinMultiplier(){return 1.45+(state.coinLevel-1)*.12;}
function luckActive(){return state.luckUntil>nowSec();}
function luckRemaining(){return Math.max(0,Math.ceil(state.luckUntil-nowSec()));}
function luckCost(){return 180+state.luckBought*90;}
function employeeWage(emp){
  const cheap=emp&&emp.skills?emp.skills.cheap:0;
  return Math.max(20,60-cheap*8);
}
function employeeWorkSeconds(emp){
  const diligent=emp&&emp.skills?emp.skills.diligent:0;
  return 3600+diligent*3600;
}
function employeeTrainingCost(emp,skill){
  const lv=emp&&emp.skills?emp.skills[skill]||0:0;
  return 120+lv*90;
}
function activeEmployeeLuckBonus(){
  ensureEmployees();
  return state.helperEmployees.reduce((sum,e)=>sum+(e.striking?0:e.skills.luck*.03),0);
}
function headChance(){
  const skillBonus=activeEmployeeLuckBonus();
  if(!luckActive())return Math.min(.95,.5+skillBonus);
  const duration=180;
  const remaining=luckRemaining();
  const timePenalty=(1-remaining/duration)*.14;
  const profitSinceLuck=Math.max(0,state.wallet-state.luckStartWallet);
  const profitPenalty=Math.max(0,profitSinceLuck-120)*.0012;
  return Math.max(.5,Math.min(.95,.82+skillBonus-timePenalty-profitPenalty));
}
function coinCost(){return 20*state.coinCount*state.coinCount;}
function upgradeCost(){return 28*state.coinLevel;}
function helperCost(){return 50+state.helperCount*40;}
function helperAutoActive(){return state.helperCount>0;}

function stakeOptions(){
  return [1,2,5,10,20,50,100];
}

function showResult(t){
  resultEl.textContent=t;resultEl.classList.add('show');
  setTimeout(()=>resultEl.classList.remove('show'),950);
}
function gainText(t){
  const d=document.createElement('div');d.className='gain';d.textContent=t;
  d.style.left=(42+Math.random()*16)+'%';d.style.top=(34+Math.random()*14)+'%';
  document.body.appendChild(d);setTimeout(()=>d.remove(),900);
}

function renderHelperStrategies(){
  if(!strategyList)return;
  ensureHelperStrategies();
  if(state.helperCount===0){
    strategyList.innerHTML='<div class="strategy-empty">雇佣助手后可以设置自动下注和收手倍率。</div>';
    return;
  }
  strategyList.innerHTML=state.helperStrategies.map((s,i)=>{
    const options=stakeOptions().map(v=>`<option value="${v}"${s.stake===v?' selected':''}>${v} 金币</option>`).join('');
    return `
      <div class="strategy-row" data-helper="${i}">
        <div class="strategy-name">助手 ${i+1}</div>
        <div class="strategy-controls">
          <label>下注
            <select class="strategy-stake">${options}</select>
          </label>
          <label>收手倍率
            <input class="strategy-cash" type="number" min="1.2" max="20" step="0.1" value="${s.cashOutAt.toFixed(1)}">
          </label>
        </div>
      </div>`;
  }).join('');
}

function updateEmployeeStrikes(){
  ensureEmployees();
  const now=nowSec();
  let changed=false;
  state.helperEmployees.forEach(e=>{
    if(!e.striking&&now>=e.paidUntil){
      e.striking=true;
      changed=true;
    }
  });
  if(changed){
    showResult('员工工资到期，开始罢工');
    saveCoinGameState();
  }
}

function employeeTimeText(emp){
  if(emp.striking)return '罢工中';
  const sec=Math.max(0,Math.ceil(emp.paidUntil-nowSec()));
  const h=Math.floor(sec/3600);
  const m=Math.ceil((sec%3600)/60);
  return h>0?h+'小时'+m+'分':m+'分钟';
}

function renderEmployees(){
  if(!employeeList||!employeeDetail)return;
  ensureEmployees();
  if(state.helperCount===0){
    employeeList.innerHTML='<div class="employee-empty">雇佣史莱姆助手后会生成员工档案。</div>';
    employeeDetail.innerHTML='';
    return;
  }
  employeeList.innerHTML='<div class="employee-list">'+state.helperEmployees.map((e,i)=>`
    <div class="employee-card${i===state.selectedEmployee?' on':''}" data-employee="${i}">
      <div class="employee-photo" style="background:${e.color}"></div>
      <div class="employee-name">${e.name}</div>
      <div class="employee-meta">${e.striking?'罢工中':'可工作'} · 工资 ${employeeWage(e)}</div>
      <div class="employee-meta">剩余 ${employeeTimeText(e)}</div>
    </div>`).join('')+'</div>';
  const emp=state.helperEmployees[state.selectedEmployee];
  if(!emp){employeeDetail.innerHTML='';return;}
  const skills=[
    ['luck','幸运','正面概率 +3% / 点'],
    ['diligent','勤劳','工作时长 +1小时 / 点'],
    ['cheap','便宜','工资 -8金币 / 点'],
    ['multi','多控','同时多控 +1枚 / 点']
  ];
  employeeDetail.innerHTML=`
    <div class="employee-detail" data-employee-detail="${state.selectedEmployee}">
      <label>名字<input id="employeeNameInput" value="${emp.name}" maxlength="10"></label>
      <div class="employee-meta">状态：${emp.striking?'罢工中，需要发工资':'工作中'} · 下次工资 ${employeeTimeText(emp)}</div>
      <button class="employee-pay" data-pay-employee="${state.selectedEmployee}">发工资 ${employeeWage(emp)} 金币</button>
      ${skills.map(([key,label,desc])=>`
        <div class="employee-skill">
          <div>${label} Lv.${emp.skills[key]}<br><span class="employee-meta">${desc}</span></div>
          <button data-train-skill="${key}">培训 ${employeeTrainingCost(emp,key)}</button>
        </div>`).join('')}
    </div>`;
}

function refresh(){
  ensureHelperStrategies();
  ensureEmployees();
  updateEmployeeStrikes();
  if(!luckActive())state.luckUntil=0;
  walletEl.textContent=Math.floor(state.wallet);
  stakeEl.textContent=Math.floor(state.stake);
  multEl.textContent='×'+state.multiplier.toFixed(2);
  potentialEl.textContent=Math.floor(state.roundValue);
  if(earnedEl)earnedEl.textContent=Math.floor(state.earned);
  if(lostEl)lostEl.textContent=Math.floor(state.lost);
  if(netEl)netEl.textContent=Math.floor(state.earned-state.lost);
  if(chanceEl)chanceEl.textContent=Math.round(headChance()*100)+'%';
  buyCoinSlot.textContent=state.coinCount<6?`增加槽位 · ${coinCost()} 金币`:'硬币槽已满';
  upgradeCoin.textContent=`提升倍率 Lv.${state.coinLevel} · ${upgradeCost()} 金币`;
  upgradeChance.textContent=luckActive()
    ? `幸运卡片 ${Math.round(headChance()*100)}% · 剩余 ${luckRemaining()} 秒`
    : `购买幸运卡片 · ${luckCost()} 金币`;
  buyHelper.textContent=state.helperCount<4?`史莱姆助手 ${state.helperCount}/4 · ${helperCost()} 金币`:'史莱姆助手已满';
  toggleAuto.textContent=helperAutoActive()?'助手自动抛币：开启':'自动策略：未雇佣';
  syncCoins(state.coinCount);syncHelpers(state.helperCount);
  renderHelperStrategies();
  renderEmployees();

  if(!state.roundActive){
    mainAction.textContent='让史莱姆抛硬币';
    hintEl.innerHTML='Q / R 调整下注 · 当前下注 '+state.stake;
  }else if(state.waiting){
    mainAction.textContent='继续让史莱姆抛';
    hintEl.innerHTML='E 收手 · Enter / 按钮继续';
  }else{
    mainAction.textContent='史莱姆正在抛…';
    hintEl.innerHTML='史莱姆正在抓取和观察硬币';
  }
}

function refreshTimedPanels(time){
  if(time<state.nextTimedUi)return;
  const wasActive=state.luckUntil>0;
  if(!luckActive())state.luckUntil=0;
  if(chanceEl)chanceEl.textContent=Math.round(headChance()*100)+'%';
  upgradeChance.textContent=luckActive()
    ? `幸运卡片 ${Math.round(headChance()*100)}% · 剩余 ${luckRemaining()} 秒`
    : `购买幸运卡片 · ${luckCost()} 金币`;
  if(wasActive&&!state.luckUntil)saveCoinGameState();
  state.nextTimedUi=time+1;
}

function startRound(){
  state.activeStrategyIndex=-1;
  return startRoundWithStake(state.stake,-1);
}

function startRoundWithStake(stake,strategyIndex){
  if(state.roundActive)return;
  const wager=clampInt(stake,state.stake,1,100);
  if(state.wallet<wager){showResult('金币不足');return;}
  state.stake=wager;
  state.activeStrategyIndex=strategyIndex;
  if(strategyIndex>=0&&state.helperStrategies.length){
    state.nextStrategyIndex=(strategyIndex+1)%state.helperStrategies.length;
  }
  state.wallet-=wager;
  state.roundStart=wager;state.roundValue=wager;state.multiplier=1;
  state.roundActive=true;state.waiting=false;state.consecutive=0;
  saveCoinGameState();refresh();throwRound();
}

function cashOut(){
  if(!state.roundActive || !state.waiting)return;
  state.wallet+=state.roundValue;
  state.earned=Math.min(999999,state.earned+Math.max(0,Math.floor(state.roundValue-state.roundStart)));
  state.best=Math.max(state.best,state.roundValue);
  showResult('落袋 +'+Math.floor(state.roundValue));
  state.roundActive=false;state.waiting=false;state.multiplier=1;state.activeStrategyIndex=-1;
  saveCoinGameState();refresh();
}

function throwRound(){
  if(!state.roundActive||!allDone())return;
  state.waiting=false;
  const release=(coinIndex,origin,yaw)=>{
    if(typeof launchCoinFromSlime==='function')launchCoinFromSlime(coinIndex,origin,yaw);
    else if(typeof launchCoinsFromSlime==='function')launchCoinsFromSlime(origin,yaw);
    else launchCoins();
  };
  if(typeof beginSlimeCoinCrewThrow==='function'){
    if(!beginSlimeCoinCrewThrow(release))return;
  }else if(typeof beginPlayerCoinThrow==='function'){
    if(!beginPlayerCoinThrow(release,0))return;
  }else{
    launchCoins();
  }
  refresh();
}

function onCoinsResolved(){
  let heads=0;
  for(let i=0;i<state.coinCount;i++)if(coins[i].result==='HEAD')heads++;
  const needed=Math.floor(state.coinCount/2)+1;

  if(heads<needed){
    showResult(`${heads}/${state.coinCount} 正面 · 未过半，本轮归零`);
    state.lost=Math.min(999999,state.lost+Math.max(0,Math.floor(state.roundStart)));
    state.roundActive=false;state.waiting=false;state.roundValue=0;state.multiplier=1;state.activeStrategyIndex=-1;
    saveCoinGameState();refresh();return;
  }

  const half=state.coinCount/2;
  const advantage=Math.min(1,Math.max(0,(heads-half)/half));
  const step=1+(coinMultiplier()-1)*advantage;
  state.multiplier*=step;
  const old=state.roundValue;
  state.roundValue=Math.max(old,Math.round(state.roundStart*state.multiplier));
  const gain=state.roundValue-old;

  if(gain>0){
    const each=Math.max(1,Math.round(gain/heads));
    for(let i=0;i<heads;i++)setTimeout(()=>gainText('+'+each),i*80);
  }

  state.consecutive++;
  state.waiting=true;showResult(`${heads}/${state.coinCount} 正面过半 · ×${step.toFixed(2)}`);
  saveCoinGameState();
  refresh();

  if(helperAutoActive()){
    state.nextAuto=performance.now()*.001+Math.max(.5,1.25-state.helperCount*.14);
  }
}

function adjustStake(dir){
  if(state.roundActive)return;
  const list=[1,2,5,10,20,50,100];
  let i=list.indexOf(state.stake);if(i<0)i=0;
  i=clamp(i+dir,0,list.length-1);state.stake=list[i];saveCoinGameState();refresh();
}

function spend(cost,fn,msg){
  if(state.wallet<cost){showResult('金币不足');return;}
  state.wallet-=cost;fn();showResult(msg);saveCoinGameState();refresh();
}

buyCoinSlot.onclick=()=>{if(state.coinCount<6)spend(coinCost(),()=>state.coinCount++,'新增大硬币');};
upgradeCoin.onclick=()=>spend(upgradeCost(),()=>state.coinLevel++,'倍率升级');
upgradeChance.onclick=()=>{
  if(luckActive()){showResult('幸运卡片正在生效');return;}
  spend(luckCost(),()=>{
    state.luckBought++;
    state.luckUntil=nowSec()+180;
    state.luckStartWallet=state.wallet;
  },'幸运卡片生效 180 秒');
};
buyHelper.onclick=()=>{if(state.helperCount<4)spend(helperCost(),()=>{state.helperCount++;state.auto=true;ensureHelperStrategies();ensureEmployees();},'史莱姆助手加入');};
toggleAuto.onclick=()=>{if(state.helperCount===0){showResult('需要史莱姆助手');return;}state.auto=true;showResult('助手会一直自动抛币');saveCoinGameState();refresh();};

if(strategyList){
  strategyList.addEventListener('change',e=>{
    const row=e.target.closest('.strategy-row');
    if(!row)return;
    const i=clampInt(row.dataset.helper,0,0,3);
    ensureHelperStrategies();
    if(!state.helperStrategies[i])return;
    if(e.target.classList.contains('strategy-stake')){
      state.helperStrategies[i].stake=clampInt(e.target.value,state.helperStrategies[i].stake,1,100);
      state.stake=state.helperStrategies[i].stake;
    }
    if(e.target.classList.contains('strategy-cash')){
      state.helperStrategies[i].cashOutAt=normalizeHelperStrategy({stake:state.helperStrategies[i].stake,cashOutAt:e.target.value},i).cashOutAt;
    }
    saveCoinGameState();refresh();
  });
}

if(employeeList){
  employeeList.addEventListener('click',e=>{
    const card=e.target.closest('.employee-card');
    if(!card)return;
    state.selectedEmployee=clampInt(card.dataset.employee,0,0,3);
    saveCoinGameState();refresh();
  });
}

if(employeeDetail){
  employeeDetail.addEventListener('change',e=>{
    if(e.target.id!=='employeeNameInput')return;
    ensureEmployees();
    const emp=state.helperEmployees[state.selectedEmployee];
    if(!emp)return;
    emp.name=e.target.value.trim().slice(0,10)||emp.name;
    saveCoinGameState();refresh();
  });
  employeeDetail.addEventListener('click',e=>{
    ensureEmployees();
    const emp=state.helperEmployees[state.selectedEmployee];
    if(!emp)return;
    const pay=e.target.closest('[data-pay-employee]');
    if(pay){
      const wage=employeeWage(emp);
      if(state.wallet<wage){showResult('金币不足，员工继续罢工');return;}
      state.wallet-=wage;
      emp.striking=false;
      emp.paidUntil=nowSec()+employeeWorkSeconds(emp);
      saveCoinGameState();refresh();
      return;
    }
    const train=e.target.closest('[data-train-skill]');
    if(!train)return;
    const skill=train.dataset.trainSkill;
    if(!emp.skills||!Object.prototype.hasOwnProperty.call(emp.skills,skill))return;
    const max=skill==='multi'?2:(skill==='diligent'||skill==='cheap'?5:10);
    if(emp.skills[skill]>=max){showResult('这个技能已满');return;}
    const cost=employeeTrainingCost(emp,skill);
    if(state.wallet<cost){showResult('金币不足，无法培训');return;}
    state.wallet-=cost;
    emp.skills[skill]++;
    saveCoinGameState();refresh();
  });
}

mainAction.onclick=()=>{
  if(!state.roundActive)startRound();
  else if(state.waiting)throwRound();
};

if(returnGame){
  returnGame.onclick=()=>{
    saveCoinGameState();
    window.location.href='../game.html?from=store';
  };
}

if(panelToggle&&sidePanel){
  panelToggle.onclick=()=>{
    const collapsed=!sidePanel.classList.contains('collapsed');
    sidePanel.classList.toggle('collapsed',collapsed);
    sidePanel.setAttribute('aria-hidden',collapsed?'true':'false');
    panelToggle.setAttribute('aria-expanded',collapsed?'false':'true');
    panelToggle.textContent=collapsed?'设置':'收起';
  };
}

addEventListener('beforeunload',saveCoinGameState);

addEventListener('keydown',e=>{
  if(e.code==='Enter'){e.preventDefault();if(!state.roundActive)startRound();else if(state.waiting)throwRound();}
  if(e.code==='KeyE'){e.preventDefault();cashOut();}
  if(e.code==='KeyQ')adjustStake(-1);
  if(e.code==='KeyR')adjustStake(1);
  if(e.code==='KeyV')viewMode=viewMode==='tp'?'near':'tp';
});

function updateAuto(time){
  refreshTimedPanels(time);
  updateEmployeeStrikes();
  if(!helperAutoActive())return;
  if(state.helperEmployees.length&&state.helperEmployees.every(e=>e.striking))return;
  ensureHelperStrategies();
  if(!state.roundActive&&allDone&&allDone()){
    const strategy=nextAffordableStrategy();
    if(!strategy){
      state.nextAuto=time+1.5;
      return;
    }
    if(!state.nextAuto)state.nextAuto=time+.65;
    if(time>=state.nextAuto){
      state.nextAuto=time+1.0;
      startRoundWithStake(strategy.stake,strategy.index);
    }
    return;
  }
  if(state.roundActive&&state.waiting&&time>=state.nextAuto){
    if(shouldAutoCashOut())cashOut();
    else throwRound();
  }
}

function nextAffordableStrategy(){
  if(!state.helperStrategies.length)return null;
  const count=state.helperStrategies.length;
  const start=clampInt(state.nextStrategyIndex,0,0,count-1);
  for(let n=0;n<count;n++){
    const index=(start+n)%count;
    const s=normalizeHelperStrategy(state.helperStrategies[index],index);
    if(state.wallet>=s.stake)return {index,stake:s.stake,cashOutAt:s.cashOutAt};
  }
  return null;
}

function activeStrategy(){
  if(state.activeStrategyIndex<0)return null;
  const s=state.helperStrategies[state.activeStrategyIndex];
  return s?normalizeHelperStrategy(s,state.activeStrategyIndex):null;
}

function shouldAutoCashOut(){
  const s=activeStrategy();
  if(!s)return false;
  return state.multiplier>=s.cashOutAt||state.roundValue>=Math.ceil(state.roundStart*s.cashOutAt);
}

loadCoinGameState();syncCoins(state.coinCount);refresh();
