'use strict';
const state={
  wallet:20, stake:1, streak:0, best:1,
  roundActive:false, awaitingDecision:false,
  coinLevel:1, helperLevel:0, auto:false, nextAutoAt:0
};

const walletEl=document.getElementById('wallet');
const stakeEl=document.getElementById('stake');
const streakEl=document.getElementById('streak');
const bestEl=document.getElementById('best');
const hintEl=document.getElementById('hint');
const resultEl=document.getElementById('result');
const upgradeCoinBtn=document.getElementById('upgradeCoin');
const buyHelperBtn=document.getElementById('buyHelper');
const toggleAutoBtn=document.getElementById('toggleAuto');

function payoutMultiplier(){return 2+(state.coinLevel-1)*.25;}
function coinUpgradeCost(){return 20*state.coinLevel;}
function helperCost(){return 45+state.helperLevel*35;}

function refreshUI(){
  walletEl.textContent=Math.floor(state.wallet);
  stakeEl.textContent=Math.floor(state.stake);
  streakEl.textContent=state.streak;
  bestEl.textContent=Math.floor(state.best);

  upgradeCoinBtn.innerHTML=`升级硬币 <span>Lv.${state.coinLevel}</span><small>正面倍率 ${payoutMultiplier().toFixed(2)}x · 价格 ${coinUpgradeCost()}</small>`;
  buyHelperBtn.innerHTML=`雇佣史莱姆助手 <span>${state.helperLevel}</span><small>价格 ${helperCost()} · 自动抛币</small>`;
  toggleAutoBtn.disabled=state.helperLevel<=0;
  toggleAutoBtn.innerHTML=`自动抛币：${state.auto?'开启':'关闭'}<small>助手会自动继续当前本轮</small>`;
  helperRoot.visible=state.helperLevel>0;

  if(!state.roundActive) hintEl.innerHTML=`按 <b>E</b> 投入 ${state.stake} 金币 · A/D 调整下注`;
  else if(state.awaitingDecision) hintEl.innerHTML=`本轮 ${Math.floor(state.stake)} · <b>E 收手</b> / <b>Space 继续</b>`;
  else hintEl.innerHTML=`按 <b>Space</b> 抛硬币`;
}

function showResult(text){
  resultEl.textContent=text;
  resultEl.classList.add('show');
  setTimeout(()=>resultEl.classList.remove('show'),900);
}

function startRound(){
  if(state.roundActive)return;
  if(state.wallet<state.stake){showResult('金币不足');return;}
  state.wallet-=state.stake;
  state.roundActive=true;
  state.awaitingDecision=false;
  state.streak=0;
  resetCoinVisual();
  showResult('投入 '+state.stake);
  refreshUI();
}

function cashOut(){
  if(!state.roundActive||!state.awaitingDecision)return;
  state.wallet+=state.stake;
  state.best=Math.max(state.best,state.stake);
  showResult('落袋 +'+Math.floor(state.stake));
  state.roundActive=false;state.awaitingDecision=false;state.streak=0;state.stake=1;
  resetCoinVisual();refreshUI();
}

function loseRound(){
  showResult('反面 · 本轮归零');
  state.roundActive=false;state.awaitingDecision=false;state.streak=0;state.stake=1;
  resetCoinVisual();refreshUI();
}

function throwCoin(){
  if(!state.roundActive||coinPhysics.active)return;
  if(state.awaitingDecision)state.awaitingDecision=false;
  launchCoin();refreshUI();
}

function onCoinResolved(result){
  if(!state.roundActive)return;
  if(result==='HEAD'){
    state.streak++;
    state.stake=Math.max(1,Math.round(state.stake*payoutMultiplier()));
    state.best=Math.max(state.best,state.stake);
    state.awaitingDecision=true;
    showResult('正面 · ×'+payoutMultiplier().toFixed(2));
  }else{
    loseRound();return;
  }
  refreshUI();

  if(state.auto&&state.helperLevel>0){
    state.nextAutoAt=performance.now()*.001+Math.max(.55,1.5-state.helperLevel*.14);
  }
}

function resetRound(){
  if(!state.roundActive)return;
  state.roundActive=false;state.awaitingDecision=false;state.streak=0;state.stake=1;
  resetCoinVisual();showResult('本轮重置');refreshUI();
}

function adjustStake(dir){
  if(state.roundActive)return;
  const steps=[1,2,5,10,20,50,100];
  let idx=steps.findIndex(v=>v===state.stake);
  if(idx<0)idx=0;
  idx=clamp(idx+dir,0,steps.length-1);
  state.stake=steps[idx];
  refreshUI();
}

upgradeCoinBtn.addEventListener('click',()=>{
  const cost=coinUpgradeCost();
  if(state.wallet<cost){showResult('金币不足');return;}
  state.wallet-=cost;state.coinLevel++;showResult('硬币升级');refreshUI();
});

buyHelperBtn.addEventListener('click',()=>{
  const cost=helperCost();
  if(state.wallet<cost){showResult('金币不足');return;}
  state.wallet-=cost;state.helperLevel++;helperRoot.visible=true;showResult('史莱姆助手加入');refreshUI();
});

toggleAutoBtn.addEventListener('click',()=>{
  if(state.helperLevel<=0)return;
  state.auto=!state.auto;
  showResult(state.auto?'自动抛币开启':'自动抛币关闭');
  refreshUI();
});

addEventListener('keydown',e=>{
  if(e.code==='KeyE'){
    e.preventDefault();
    if(!state.roundActive)startRound();
    else if(state.awaitingDecision)cashOut();
  }
  if(e.code==='Space'){
    e.preventDefault();
    if(state.roundActive&&!coinPhysics.active)throwCoin();
  }
  if(e.code==='KeyA')adjustStake(-1);
  if(e.code==='KeyD')adjustStake(1);
  if(e.code==='KeyR')resetRound();
});

function updateGameAuto(time){
  if(!state.auto||state.helperLevel<=0)return;

  if(!state.roundActive){
    if(state.wallet>=1&&time>=state.nextAutoAt){
      state.stake=1;startRound();state.nextAutoAt=time+.8;
    }
    return;
  }

  if(state.awaitingDecision&&time>=state.nextAutoAt){
    throwCoin();
    state.nextAutoAt=time+Math.max(.55,1.5-state.helperLevel*.14);
  }else if(!state.awaitingDecision&&!coinPhysics.active&&time>=state.nextAutoAt){
    throwCoin();
  }
}
refreshUI();
