'use strict';
const tableG=new THREE.Group();scene.add(tableG);
put(box(3.9,.18,2.6,MAT_WOOD),0,1,0,0,0,0,tableG);
put(box(4.05,.08,2.75,MAT_WOOD_DARK),0,.88,0,0,0,0,tableG);
for(const [x,z] of [[-1.7,-1.05],[1.7,-1.05],[-1.7,1.05],[1.7,1.05]]){
  put(edge(new THREE.CylinderGeometry(.08,.10,1.7,7),MAT_WOOD_DARK),x,0,z,0,0,0,tableG);
}
for(const r of [.46,.62]){
  const ring=edge(new THREE.TorusGeometry(r,.015,6,40),MAT_COIN_DARK);
  ring.rotation.x=Math.PI/2; ring.position.set(0,1.105,0); tableG.add(ring);
}

const helperRoot=new THREE.Group();helperRoot.position.set(1.55,1.34,.62);helperRoot.visible=false;scene.add(helperRoot);
const helperBody=new THREE.Mesh(new THREE.SphereGeometry(.28,20,14),MAT_SLIME);helperRoot.add(helperBody);
helperRoot.add(new THREE.LineSegments(new THREE.EdgesGeometry(helperBody.geometry,18),MAT));
const helperCore=new THREE.Mesh(new THREE.SphereGeometry(.12,12,8),MAT_SLIME_CORE);helperRoot.add(helperCore);
for(const x of [-.075,.075]){
  const eye=new THREE.Mesh(new THREE.SphereGeometry(.022,8,6),fillMat(0x29332e));
  eye.position.set(x,.055,.255);helperRoot.add(eye);
}
function updateHelper(time){
  if(!helperRoot.visible)return;
  helperRoot.position.y=1.34+Math.sin(time*2.3)*.018;
  helperBody.scale.y=.96+Math.sin(time*4)*.03;
}
