'use strict';
const coinRoot=new THREE.Group();coinRoot.position.set(0,1.28,0);scene.add(coinRoot);
const coinGeo=new THREE.CylinderGeometry(.24,.24,.055,32);
const coinMesh=new THREE.Mesh(coinGeo,MAT_COIN);coinRoot.add(coinMesh);
coinRoot.add(new THREE.LineSegments(new THREE.EdgesGeometry(coinGeo,16),MAT));
coinMesh.rotation.z=Math.PI/2;coinRoot.children[1].rotation.z=Math.PI/2;

const headMark=edge(new THREE.TorusGeometry(.095,.014,6,20),MAT_COIN_DARK);
headMark.position.x=.031;headMark.rotation.y=Math.PI/2;coinRoot.add(headMark);

const tailMark=edge(new THREE.BoxGeometry(.15,.035,.035),MAT_COIN_DARK);
tailMark.position.x=-.031;tailMark.rotation.z=Math.PI/2;coinRoot.add(tailMark);

const coinPhysics={active:false,resolved:false,pos:new THREE.Vector3(),vel:new THREE.Vector3(),angVel:new THREE.Vector3(),bounceCount:0,result:null};

function resetCoinVisual(){
  coinPhysics.active=false;coinPhysics.resolved=false;coinPhysics.bounceCount=0;coinPhysics.result=null;
  coinPhysics.pos.set(0,1.28,0);coinPhysics.vel.set(0,0,0);coinPhysics.angVel.set(0,0,0);
  coinRoot.position.copy(coinPhysics.pos);coinRoot.rotation.set(0,0,0);
}

function launchCoin(){
  if(coinPhysics.active)return;
  coinPhysics.active=true;coinPhysics.resolved=false;coinPhysics.bounceCount=0;coinPhysics.result=null;
  coinPhysics.pos.set(0,1.30,0);
  coinPhysics.vel.set((Math.random()-.5)*.7,5.1+Math.random()*.7,(Math.random()-.5)*.7);
  coinPhysics.angVel.set(10+Math.random()*5,3+Math.random()*4,16+Math.random()*7);
  coinRoot.position.copy(coinPhysics.pos);
}

function settleResult(){
  const up=new THREE.Vector3(0,1,0).applyQuaternion(coinRoot.quaternion);
  coinPhysics.result=up.y>=0?'HEAD':'TAIL';
  coinPhysics.resolved=true;coinPhysics.active=false;
  onCoinResolved(coinPhysics.result);
}

function updateCoin(dt){
  if(!coinPhysics.active)return;

  coinPhysics.vel.y-=12.5*dt;
  coinPhysics.pos.addScaledVector(coinPhysics.vel,dt);

  coinRoot.rotation.x+=coinPhysics.angVel.x*dt;
  coinRoot.rotation.y+=coinPhysics.angVel.y*dt;
  coinRoot.rotation.z+=coinPhysics.angVel.z*dt;

  const floorY=1.34;
  if(coinPhysics.pos.y<=floorY && coinPhysics.vel.y<0){
    coinPhysics.pos.y=floorY;

    if(coinPhysics.bounceCount<2 && Math.abs(coinPhysics.vel.y)>.8){
      coinPhysics.vel.y*=-.34;
      coinPhysics.vel.x*=.70;coinPhysics.vel.z*=.70;
      coinPhysics.angVel.multiplyScalar(.58);
      coinPhysics.bounceCount++;
    }else{
      coinPhysics.vel.set(0,0,0);
      coinPhysics.angVel.multiplyScalar(.86);

      if(coinPhysics.angVel.length()<.7){
        const up=new THREE.Vector3(0,1,0).applyQuaternion(coinRoot.quaternion);
        const head=up.y>=0;
        const targetQ=new THREE.Quaternion().setFromEuler(new THREE.Euler(head?0:Math.PI,0,Math.PI/2));
        coinRoot.quaternion.slerp(targetQ,Math.min(1,dt*9));
        if(coinRoot.quaternion.angleTo(targetQ)<.03){
          coinRoot.quaternion.copy(targetQ);
          settleResult();
        }
      }
    }
  }
  coinRoot.position.copy(coinPhysics.pos);
}
resetCoinVisual();
